# Generic Schematic Device Wrapper PCell

This directory contains a schematic-only device wrapper. The user-visible cell
name and symbol stay fixed, while `FABTECHLIBNAME` selects the current PDK and
the first Q-form parameter, `device`, selects one real PDK device in that PDK.

The wrapper owns only its static `symbol`, schematic PCell, and wrapper CDF. It
does not create, copy, wrap, generate, open for write, or modify `layout` or
`maskLayout`. XL must continue to resolve the official PDK layout PCell.

## Layout XL internal-source validation

Build 19 keeps the focused validation entry point for making the official `M0`
inside the wrapper schematic PCell the Layout XL logical source. It does not
create layout geometry or define a wrapper layout PCell. It updates the current
Layout XL physical hierarchy, leaf binding, and existing layout instance
parameters.

Open Layout XL from the top-level schematic, select exactly one already bound
official layout instance in the Layout XL window, and run:

```skill
CWDeviceEnableXLInternalSource()
```

The selected layout instance must currently bind to exactly one outer wrapper.
The procedure opens that wrapper instance's evaluated schematic PCell, checks
that `M0` and the selected layout instance use the same official PDK library and
cell, sets force-descend on the wrapper, assigns the selected official layout
master as the physical binding of `M0`, rebuilds the Layout XL source leaves,
and replaces the outer binding with:

```text
wrapperInstance/M0 <-> selectedOfficialLayoutInstance
```

Success ends with:

```text
CWDeviceXL COMPLETE source=<wrapperName>/M0 layout=<layoutName> master=<lib cell view>
```

The procedure then starts the documented Layout XL **Update Layout
Parameters** command. Confirm the layout instance's effective device and
parameter values match the internal official `M0`. `CWDeviceXL READBACK` must report
`outerStillBound=nil` and a non-nil `innerIsBound`. Any error result means the
internal-source behavior is not established in that live environment; do not
treat the old outer-wrapper binding as an acceptable fallback.

## Delivered files

- `CWLoadYaml.il`: generic block-style YAML reader for ordered mappings and
  sequences. It does not contain device logic.
- `CWDevicePCell.il`: source-device discovery, wrapper CDF, schematic PCell,
  native-Q proxy, validation, and logging.
- `device_wrapper.example.yaml`: mapping example for two wrapper families and
  two technology environments.
- `CWDeviceREADME.md`: setup and validation notes.

## YAML configuration

```yaml
wrappers:
  nmos:
    technologies:
      techlibA:
        ports:
          D: D
          G: G
          S: S
          B: B

        devices:
          nfet_lvt:
          nfet_rvt:
          nfet_ulvt:
            ports:
              D: drain
              G: gate
              S: source
              B: bulk
```

`nmos` is the fixed wrapper cell name. `techlibA` must exactly match the value
of `FABTECHLIBNAME`. Each key below `devices` is the real PDK cell name.

The technology-level `ports` mapping is the default. A device may contain its
own `ports` mapping to replace that default completely. Empty device nodes are
therefore valid and inherit the technology-level mapping.

Do not configure selector metadata, `vt`, `cell`, `view`, library names, CDF
parameters, defaults, choices, visibility, or callbacks in YAML. The program
always creates `device` as the first selector. Native parameter names and
values are captured directly from the selected official instance after its Q
form closes.

`CWLoadYaml()` also supports general block sequences. Mappings return the
existing ordered table representation, while sequences return native SKILL
lists. Supported sequence shapes include:

```yaml
names:
  - nfet_lvt
  - nfet_rvt

devices:
  - name: nfet_lvt
    ports:
      D: D
      G: G
  - name: nfet_rvt

groups:
  -
    - core
    - io
```

Flow collections such as `[core, io]` and `{name: nfet}` remain unsupported.
The device-wrapper schema itself continues to use the mapping form shown above;
sequence support belongs to the generic loader and does not change that schema.

## Source library search

For each device cell, the first library containing its `symbol` wins:

```text
FABTECHLIBNAME
FABTECHLIBNAME_esd
FABTECHLIBNAME_macro
FABTECHLIBNAME_stackmos
FABTECHLIBNAME_tech
```

Missing derived libraries are skipped. Once a symbol is found, invalid ports or
a missing source CDF are reported for that library; the program does not hide a
bad main-library definition by continuing to a lower-priority library.

## Installation and session initialization

`FABTECHLIBNAME` is mandatory. Export it before starting Virtuoso and make
sure it exactly matches one technology key in the YAML file. There is no
default technology and `tsmcN65` is not selected implicitly. If the variable
is missing, `libInit.il` prints `ENV_MISSING` and returns without modifying
wrapper CDF/PCell definitions; direct installation and session initialization
entries return the same error.

The wrapper library must already contain a complete static `symbol` for every
wrapper cell, such as `nmos/symbol` and `pmos/symbol`. This includes its drawing,
pins, one `@device` label for the selected real device name, and intended
parameter labels such as `cdsParam(1)`. Installation and session restoration open this symbol
read-only to validate configured terminals. It never adds, moves, deletes, or
saves symbol labels. The schematic PCell and base CDF for those cells are
managed by this program.

An administrator performs persistent generation once while the wrapper library
is writable:

```skill
load("/site/device_wrapper/CWLoadYaml.il")
load("/site/device_wrapper/CWDevicePCell.il")
CWDeviceInstall(
    "device_wrapper_lib"
    "/site/device_wrapper/device_wrapper.yaml"
    "/tmp/device_wrapper_init.log"
)
```

The two `load(...)` calls only define procedures. The third call,
`CWDeviceInstall(...)`, performs persistent generation and must print
`CWDeviceConfigure START mode=INSTALL`, the log path, and one `DEFINE_PCELL` target for
each wrapper. A successful call returns `list('ok fabLib wrapperLib
wrapperNames)` and creates each wrapper at `wrapperLib/wrapperCell/schematic`.

The administrator log directory must already exist and be writable. If a non-nil log path
cannot be opened, installation stops with `LOG_OPEN`; passing nil explicitly
prints `LOGGING_DISABLED` and continues without a file log.

If an earlier failed run created an ordinary `schematic` view at the wrapper
target, remove only that generated `schematic` view before retrying. Keep the
static `symbol` view. `pcDefinePCell` cannot create the schematic super master
while an incompatible ordinary view occupies the same target.

After administrator installation, publish the wrapper library read-only. Its
`libInit.il` calls:

```skill
CWDeviceSessionInitialize(wrapperLib yamlFile)
```

This user-session entry reads YAML and official PDK metadata and restores
`CWDeviceRuntime`. It does not define PCells, rebuild CDFs, create log files,
or write any data into the wrapper library. Administrator installation stores
a hidden `installedFabLib` marker in each wrapper CDF. Session restoration
requires that marker to match `FABTECHLIBNAME`; a missing or different marker
stops with `INSTALL_REQUIRED` or `INSTALLED_FAB_MISMATCH` instead of silently
regenerating the read-only library.

One Virtuoso session is treated as one PDK environment. If
`FABTECHLIBNAME` changes after successful session restoration, restart Virtuoso.

Administrator installation is a generation step. It embeds the current technology's real
device libraries, cells, port mappings, native defaults, and interpreted-label
metadata into each schematic PCell definition. The generated PCell body does
not call `CWDevicePCellBody`, read `CWDeviceRuntime`, or load YAML during PCell
evaluation. SI can therefore reevaluate the generated schematic PCell without
running `CWDeviceInstall()` in the SI process. The official target PDK must
still be loaded normally in the SI environment.

## Q-form and PCell behavior

Installation and session restoration validate that every configured real device has an official
symbol, mapped terminals, and effective CDF. The wrapper PCell contains visible
`device`, hidden `snapshots`, and the minimum hidden backing parameters required
by the prebuilt symbol's `cdsParam(n)` labels. These backing parameters are not
user-editable Q fields and are synchronized only from the native snapshot.

The wrapper Q contains only `device` and `Edit Native Parameters`.
`CWDeviceRuntimeKey` is a hidden, non-saved CDF field used by callbacks. The
complete official PDK parameter form is available only through `Edit Native
Parameters`.

Runtime ownership is intentionally single-entry: `libInit.il` loads the two
source files and calls `CWDeviceSessionInitialize()`. Callback execution never loads
these files and never calls initialization again. If a persisted instance is
opened while its session runtime is absent, the callback reports
`RUNTIME_UNAVAILABLE`; run the library's `libInit.il` session restoration once in
that Virtuoso session.

When the outer Q opens, `formInitProc` binds that form to the exact CDF target
cellview and wrapper instance. The Native-Q button consumes that binding; it
does not scan other open windows for a same-named instance.

The proxy scratch cell is created in the wrapper instance's parent design
library, never in the read-only wrapper PCell library. It is never saved.
Cleanup uses `dbPurge()` to discard
the temporary database state and empty its graphical window before closing the
window and removing the scratch cell. This avoids routing a dirty schematic
through the editor's Save/Discard dialog. In environments where `dbPurge()`
also destroys the graphical window, cleanup recognizes that the stored window
is no longer in `hiGetWindowList('all)` and does not call `hiCloseWindow()` on
the invalid window ID.

Press `Edit Native Parameters` to finish the wrapper Q and schedule one
transient scratch operation. After the button event returns to the Virtuoso GUI
loop, `CWDeviceOpenNative()` linearly opens the scratch schematic, creates the
temporary official PDK symbol instance, connects every mapped terminal to a
scratch net, applies the stored snapshot, selects the instance, and requests
its official Q. Connected wrapper ports use the edited occurrence's actual
parent net name. Floating wrapper ports use the wrapper port name. Shared
parent nets are reused inside the scratch schematic. The database view starts in
Virtuoso scratch mode and is purged rather than saved after the proxy closes.
The official PDK therefore owns its field presentation, `formInitProc`,
callbacks, visibility, editability, choices, and returned values. If the
window, instance, CDF, or selection cannot be established, the proxy reports a
stage-specific error and cleans up. Only one native proxy session can be active
at a time.

Native Q owns its visible lifetime. `CWDeviceWatchNative()` is the only repeated
timer callback. `CWDeviceOpenNative()` retains the valid property form as soon
as `schHiObjectProperty()` returns, so both immediate and deferred GUI timer
dispatch are supported. The watcher follows that retained form, keeps waiting
while it is displayed, and calls `CWDeviceFinishNative()` after it closes to
perform the linear readback and cleanup. The watcher never changes form actions
or instance values, and it does not require the form to be displayed twice.

The Native Q retains its official PDK Done and Cancel actions. Parameter
callbacks, Apply, OK, and Cancel therefore execute through the unmodified PDK
form. Apply affects the temporary official instance but does not immediately
update the wrapper. After the Native Q finally closes, the proxy reads the
official instance CDF, compares it with the opening baseline, writes changed
values to `snapshots`, regenerates the wrapper, and cleans up. There is no
watchdog or destructive form-lifetime timeout in this build.

During Create Instance, the wrapper form can initialize before its OA instance
exists. This is reported as `FORM_CONTEXT_DEFERRED`, not
`FORM_CONTEXT_BIND`. Native Q requires an existing wrapper instance and becomes
available through the normal instance Q after placement is complete.

After the official Q closes, every non-button native parameter name and value
is stored in the hidden `snapshots` ilList PCell parameter on the original
wrapper instance. Each technology snapshot is one flat DPL containing
`fabLib`, the currently selected `device`, and the real native parameter names
and values directly. Entries are keyed only by
`FABTECHLIBNAME`. Changing `device` rebuilds and replaces that technology's DPL.
The current technology is stored first and only the most recently used different
technology is retained, so each wrapper instance stores at most two DPLs. No
string serialization or `readstring()` step is used. Nested Build 12 snapshots
remain read-compatible in both the session code and the generated self-contained
PCell body. Existing flat snapshots that contain the obsolete version property
remain readable; that property is removed on the next successful write.

Changing `device` rebuilds the current technology snapshot from the newly
selected device. Values start from the official CDF defaults discovered during
installation and are replaced by later Native Q results. Old-device values are
discarded. The previous technology snapshot remains isolated in `snapshots`,
while older technology snapshots are discarded; none are expanded into separate
User Properties.

Installation does not modify the static symbol. The selected real device name
is displayed by the prebuilt symbol's `@device` label. Existing `cdsParam(1)`
and later interpreted labels continue to use the official raw `paramLabelSet`,
`paramDisplayMode`, and `paramEvaluate` metadata. Only the parameters named by
that label set receive hidden backing values. Label-control tokens such as
`-model` remain metadata and do not create backing parameters. `@device` is an
independent symbol-property label and does not replace or reorder `cdsParam(n)`.

Native Q results are committed to `snapshots` and copied only into the hidden
symbol-label backing parameters. Regenerating the wrapper PCell applies the
current snapshot to the selected official internal instance. Changing `device`
commits the new selector value before rebuilding its snapshot and label values.
Press `Edit Native Parameters` again to edit that device's official CDF.

External automation may edit the DPL returned by `CWDeviceGetSnapshots()` and
call `CWDeviceCommitSnapshots(inst)`. The update is transactional: the first
PCell evaluation applies the edited values and runs the official PDK callback;
the callback-confirmed CDF is then captured and written back to the snapshot,
followed by a second atomic PCell replacement. If either regeneration fails,
the previous snapshot and evaluated parameter list are restored. A successful
transaction also reads the technology/device values back from the same wrapper
instance and requires exact name/type/value equality; otherwise it reports
`SNAPSHOT_READBACK_FAILED` and restores the previous state.

The schematic PCell separately creates one selected official PDK symbol
instance. For every mapped port, it inherits the source terminal direction,
finds the source symbol pin position, extends a short wire outward from the
source symbol, and creates a same-name `basic/ipin`, `basic/opin`, or
`basic/iopin`. The generated schematic terminal, `wire/drawing` line, and
official source instance terminal share the same net. The external pin first
establishes the terminal and net; the short line and official instance terminal
are then attached to that same net. No pin direction is configured in YAML.
When the mapped wrapper ports contain `D`, `G`, `S`, and `B`, the wrapper uses
the fixed MOS convention: `G` extends left, `B` extends right, and `D/S` extend
vertically according to their relative Y coordinates. The higher of `D/S`
extends upward and the lower extends downward. All other device families keep
the generic symbol-position rule.
When the schematic editor API is loaded, wire creation first uses
`schCreateWire()`; the self-contained PCell keeps `dbCreateLine()` as an OA
fallback for reduced SI contexts. Both paths assign the created segment to the
same wrapper net.

The wrapper schematic PCell receives `device`, the hidden symbol-label backing
parameters, and the hidden `snapshots` ilList parameter. The current technology
is fixed in the generated PCell definition rather than carried as a
source-technology instance parameter. It restores only the callback-confirmed
current technology snapshot when its stored device matches the selected device,
and applies parameters owned by the selected official instance. At most one
previous-technology snapshot remains stored, and it is not passed to the active
device.

The hidden value can be read directly from the wrapper instance:

```skill
snapshots = inst~>snapshots
snapshot = car(snapshots)
snapshot->fabLib
snapshot->device
snapshot->l
snapshot->m
```

If `l`, `nfin`, `n`, or `m` is referenced by `paramLabelSet`, an instance may
contain that hidden backing property for symbol display. It is not a supported
write interface. Native parameter edits go through the official Q proxy, and
their complete callback-confirmed state stays inside `snapshots`.

The wrapper base CDF is deleted and rebuilt during administrator installation. Do not keep
independent manually maintained CDF parameters on these wrapper cells. During
that rebuild the wrapper's simulator `simInfo` is cleared. The device selector,
native-edit callback, `formInitProc`, and interpreted-label metadata remain, but
the wrapper does not identify itself as a primitive simulator component. The
expected CDL shape is a parent `X` call into the wrapper schematic subcircuit,
where the internal official PDK instance emits its native device statement.

## Validation boundary

Local static checks cover the YAML contract, source structure, parentheses,
ASCII text, control-flow style, exact API-reference lookup, and the absence of
direct layout-geometry creation or deletion. They do not prove live Virtuoso,
PDK callback, PCell, or XL behavior. The XL validation procedure intentionally
updates binding state and existing layout instance parameters.

Validate the following on the company server in a disposable wrapper library:

1. Confirm the wrapper Q contains only `device` and `Edit Native Parameters`.
2. Select one real device, press `Edit Native Parameters`, and confirm the
   temporary schematic appears in the edited design library and the selected
   official device Q opens. Confirm no scratch cell or log file is created in
   the wrapper PCell library.
3. Confirm the official Q has native parameters, choices, visibility,
   editability, `formInitProc`, and callback behavior.
4. Change a parameter that triggers a known PDK callback and confirm the
   callback-returned values are visible in the official Q.
5. Inspect the Native-Q scratch schematic before closing Q. Confirm every
   mapped official terminal is connected to a scratch net with the wrapper
   occurrence's actual external net name. Confirm two ports sharing one parent
   net reuse one scratch net.
6. Close the official Q and inspect `CWDeviceProxy COPY_BACK`; confirm the
   wrapper PCell regenerates with the changed native values.
7. Reopen the same wrapper/device and confirm the saved native values return.
8. Place a second wrapper instance, use different values, and confirm neither
   instance changes the other.
9. Open two different schematics that both contain an `M1` wrapper instance.
   Open Q from each schematic separately and confirm `FORM_CONTEXT_BOUND`
   reports the correct parent cellview and Native Q edits only that instance.
10. Switch the first wrapper between two devices and confirm each device restores
   only its own saved values while an unedited device starts from PDK defaults.
11. Confirm native values do not appear as editable Q fields. Only the values
   referenced by `paramLabelSet` may exist as hidden symbol-label properties.
12. Confirm installation did not modify the prebuilt symbol. Verify `@device`
    displays the selected real device name and the existing `cdsParam(n)` labels
    follow the same official PDK label order that previously displayed
    successfully.
13. Confirm a device-specific port override preserves schematic connectivity.
14. Regenerate the schematic PCell and inspect every generated pin direction.
15. Confirm each short wire extends outward from the corresponding source symbol
   pin and reaches the wrapper schematic pin.
16. Run Check and Save and confirm all wrapper pins connect to the intended
   official source-instance terminals without dangling or duplicate nets.
17. Regenerate the schematic PCell and inspect the internal instance master.
18. Run XL and confirm it uses the official PDK layout PCell. No wrapper layout
    view should exist.
19. Start SI CDL extraction without loading `CWDevicePCell.il` or calling
    `CWDeviceInstall()` inside SI. Confirm there is no `undefined function
    CWDevicePCellBody` or `CWDeviceRuntime` PCell evaluation error.
20. Confirm the parent netlist contains an `X` call for the wrapper, the wrapper
    has a `.SUBCKT` definition with the expected terminal order, and the wrapper
    body contains the official PDK device statement. Confirm the wrapper is not
    printed directly as a MOS primitive.

After changing this source, close any open wrapper Q forms, reload
`CWLoadYaml.il` and `CWDevicePCell.il`, and run administrator installation again. Place a new
wrapper instance for the cleanest check. Existing instances may still physically
contain historical User Properties from older builds, but rebuilt CDF/PCell code
does not display or consume them. Delete or regenerate stale PCell submasters as
required before checking the new schematic result.

Simulation, netlisting, DRC, LVS, extraction, reliability, and signoff still
require the normal target-PDK qualification flow.
