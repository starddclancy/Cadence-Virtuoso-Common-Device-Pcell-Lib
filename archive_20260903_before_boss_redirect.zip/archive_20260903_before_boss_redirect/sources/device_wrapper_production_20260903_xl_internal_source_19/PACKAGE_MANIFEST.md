# device_wrapper final package

Package date: 2026-09-03

Build ID: `20260903-xl-internal-source-19`

This package contains the production candidate for the schematic device-wrapper
PCell. Python/RAMIC utilities and the historical `tsmcN65` template are not
part of this package.

## Required environment

Set `FABTECHLIBNAME` before Virtuoso starts. The value must match a technology
entry in `device_wrapper.example.yaml`. No technology fallback is used. The
deployed library may be read-only: `libInit.il` restores session runtime only
and does not define PCells, create CDF data, write logs, or create scratch data
inside the wrapper library.

## Files

- `CWLoadYaml.il` - restricted block-YAML reader.
- `CWDevicePCell.il` - wrapper PCell, CDF, snapshot, callback, Native-Q,
  validation, rollback, and cleanup implementation.
- `libInit.il` - guarded library initialization hook.
- `device_wrapper.example.yaml` - schema/example configuration; replace with
  the target PDK mapping.
- `CWDeviceREADME.md` - setup, behavior, snapshot format, and validation flow.

## Administrator installation

```skill
load("/absolute/path/device_wrapper/CWLoadYaml.il")
load("/absolute/path/device_wrapper/CWDevicePCell.il")
CWDeviceInstall(
    "test_device"
    "/absolute/path/device_wrapper/device_wrapper.example.yaml"
    "/writable/path/device_wrapper_install.log"
)
```

After installation, publish the wrapper library read-only. For normal use,
install `libInit.il` in that library; it calls `CWDeviceSessionInitialize()` and
restores only session-local runtime data after verifying the persisted
`installedFabLib` marker. Native-Q scratch cells are created in
the edited wrapper instance's parent design library and deleted after use.

This build removes the general Native-Q phase state machine. One delayed call
returns the button event to the GUI before `CWDeviceOpenNative()` performs the
linear scratch setup. `CWDeviceWatchNative()` is the only repeated timer and
only observes whether the form has ever appeared and whether it later closes.
`CWDeviceFinishNative()` then performs linear readback, wrapper regeneration,
and cleanup. The PDK owns its unchanged OK/Apply/Cancel actions.

After `schHiObjectProperty()` returns, the valid Native-Q form is retained
immediately and counts as having appeared. This supports both GUI environments
that dispatch the watcher while Q is displayed and environments that defer the
watcher until Q closes. The watcher follows the retained form instead of a
later unrelated global property form.

Cleanup keeps `dbPurge()` before window handling so an unsaved scratch view
cannot open a Save/Discard dialog. Some graphical environments destroy that
window during the purge. `hiCloseWindow()` is therefore called only when the
stored window remains in `hiGetWindowList('all)`; an already destroyed window
is a successful cleanup state rather than an active-proxy failure.

The wrapper Q is completed before the delayed scratch operation starts. The
official instance is created only in that later GUI cycle, so the Native-Q
button release cannot descend into the temporary instance.

All database-instance identity reads use the OA instance `name` property. Form
field names and internal state keys may still contain `instName`, but no
database object is accessed through an `instName` property.

Once Native Q is displayed, validation failures and manual abort cannot purge
its scratch cellview. Cleanup is deferred through the same passive watcher until
the user closes Native Q. Only then may the scratch cellview and window be
removed.

Each newly written technology snapshot is one flat DPL containing `fabLib`,
`device`, and direct native parameter properties. Switching device rebuilds the
current technology DPL, and at most one previous technology is retained. Nested
Build 12 snapshots remain readable and migrate to the flat format on the next
successful commit. Existing flat snapshots with the obsolete version property
remain readable and lose that property on the next successful commit.
The generated PCell body contains no `dplp()` dependency.

Create-instance form initialization can occur before the wrapper OA instance
exists. That condition returns success with `FORM_CONTEXT_DEFERRED`; a genuine
existing-instance mismatch remains `FORM_CONTEXT_BIND`.

Build 19 updates `CWDeviceEnableXLInternalSource()` to rebuild the Layout XL
source leaves after force-descend is set, retain the explicit hierarchical
`<wrapperName>/M0` binding, and start the documented Layout XL Update Layout
Parameters command. It does not create layout geometry or define a wrapper
layout PCell, and it does not explicitly save the layout cellview.

The wrapper schematic PCell and Native-Q scratch flow use the same MOS-specific
direction rule when the wrapper mapping contains D, G, S, and B: G exits left,
B exits right, and D/S exit vertically according to their relative Y
coordinates. Other device families retain the generic symbol-position rule.
Native-Q scratch `M0` is connected before the PDK Q opens. Mapped wrapper ports
reuse the edited wrapper occurrence's actual parent net names, while floating
ports use their wrapper port names.
