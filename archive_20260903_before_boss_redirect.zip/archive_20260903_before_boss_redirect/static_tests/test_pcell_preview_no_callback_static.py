from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / "device_wrapper_production_20260902_nativeq_linear_17"
    / "CWDevicePCell.il"
)


def procedure_body(source: str, name: str, next_name: str) -> str:
    start = source.index(f"procedure({name}")
    end = source.index(f"procedure({next_name}", start)
    return source[start:end]


def main() -> None:
    source = SOURCE.read_text(encoding="utf-8")
    assert 'CWDeviceBuildId = "20260902-nativeq-linear-17"' in source

    body = procedure_body(
        source,
        "CWDeviceBuildPCellBody",
        "CWDeviceDefinePCell",
    )
    assert "cdfUpdateInstParam(" not in body
    assert "deOpenCellView(" not in body
    assert "schHiObjectProperty(" not in body
    assert "dbReplaceProp(" in body
    assert "get(targetParameter 'paramType)" in body
    assert body.index("get(targetParameter 'paramType)") < body.index("nth(1 pair)")
    assert "member(\n                                        pairType" in body
    assert 'pairType = "string"' in body
    assert 'pairType = "boolean"' in body
    assert 'pairType = "ILList"' in body

    native_body = procedure_body(
        source,
        "CWDeviceOpenNative",
        "CWDeviceWatchNative",
    )
    assert "cdfUpdateInstParam(targetInst)" in native_body
    assert "schHiObjectProperty()" in native_body


if __name__ == "__main__":
    main()
