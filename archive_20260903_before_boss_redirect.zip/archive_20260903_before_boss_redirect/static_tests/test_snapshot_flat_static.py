from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_snapshot_flat_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

set_start = source.index("procedure(CWDeviceSetSnapshotValues")
set_end = source.index("procedure(CWDeviceGetSnapshots", set_start)
set_snapshot = source[set_start:set_end]

read_start = source.index("procedure(CWDeviceSnapshotValues")
read_end = source.index("procedure(CWDeviceSetSnapshotValues", read_start)
read_snapshot = source[read_start:read_end]

validate_start = source.index("procedure(CWDeviceValidateSnapshots")
validate_end = source.index("procedure(CWDeviceUpdateFromSnapshots", validate_start)
validate_snapshot = source[validate_start:validate_end]

body_start = source.index("procedure(CWDeviceBuildPCellBody")
body_end = source.index("procedure(CWDeviceDefinePCell", body_start)
pcell_body = source[body_start:body_end]

assert "'devices" not in set_snapshot, "A technology snapshot must contain only the current device"
assert "'parameters" not in set_snapshot, "Snapshot parameters must be direct DPL properties"
assert "'fabLib fabLib 'device deviceName" in set_snapshot, "Snapshot must identify its technology and current device"
assert "length(updated) <= 2" in set_snapshot, "At most current and previous technology snapshots may remain"

assert "get(snapshot 'device) == deviceName" in read_snapshot, "Snapshot lookup must match the direct device property"
assert read_snapshot.index("get(snapshot 'device) == deviceName") < read_snapshot.index("get(snapshot 'devices)"), "Flat snapshot lookup must be the primary path"

assert "get(snapshot 'fabLib)" in validate_snapshot, "Validation must require a technology key"
assert "get(snapshot 'device)" in validate_snapshot, "Validation must require a direct device key"

assert "dplp(" not in pcell_body, "Self-contained PCell body must not depend on the UI dplp helper"
assert "get(tech 'device) == device" in pcell_body, "PCell body must read the flat current-device snapshot"
