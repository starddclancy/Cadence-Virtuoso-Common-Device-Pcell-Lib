from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_nativeq_official_commit_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

open_start = source.index("procedure(CWDeviceOpenNative")
open_end = source.index("procedure(CWDeviceWatchNative", open_start)
open_native = source[open_start:open_end]

watch_start = open_end
watch_end = source.index("procedure(CWDeviceFinishNative", watch_start)
watch_native = source[watch_start:watch_end]

assert "hiChangeFormCallback(" not in source, "Official Native Q actions must not be replaced"
assert "CWDeviceProxyNativeAction" not in source, "Proxy action wrappers must be removed"
assert "nativeDoneAction" not in source, "Official Done action must remain owned by the PDK form"
assert "nativeCancelAction" not in source, "Official Cancel action must remain owned by the PDK form"
assert open_native.index("schHiObjectProperty()") > open_native.index("geSelectFig(targetInst)"), "Native Q must open only after target selection"
assert "state['formSeen] = nil" in open_native, "Native Q must start with an unseen-form marker"
assert "state['formSeen] = t" in watch_native, "Watcher must mark the official form as seen"
assert "CWDeviceFinishNative(proxyKey)" in watch_native, "Only watcher close detection may trigger copy-back"
assert "CWDeviceUpdateFromSnapshots(" in source, "Copy-back must regenerate through the wrapper transaction"
