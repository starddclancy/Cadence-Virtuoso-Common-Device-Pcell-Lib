from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit(
        "usage: test_nativeq_cleanup_destroyed_window_static.py CWDevicePCell.il"
    )

source = Path(sys.argv[1]).read_text(encoding="ascii")

cleanup_start = source.index("procedure(CWDeviceProxyCleanup")
cleanup_end = source.index("procedure(CWDeviceDeleteScratch", cleanup_start)
cleanup = source[cleanup_start:cleanup_end]

abort_start = source.index("procedure(CWDeviceProxyAbort")
abort_end = source.index("procedure(CWDeviceStartProxy", abort_start)
abort = source[abort_start:abort_end]

delete_start = source.index("procedure(CWDeviceDeleteScratch")
delete_end = source.index("procedure(CWDeviceError", delete_start)
delete_scratch = source[delete_start:delete_end]

window_list = "hiGetWindowList('all)"
close_window = "hiCloseWindow(window)"

assert window_list in cleanup, "Cleanup must query live windows after dbPurge"
assert cleanup.index("dbPurge(scratch)") < cleanup.index(window_list), (
    "Scratch purge must remain before graphical window cleanup"
)
assert cleanup.index(window_list) < cleanup.index(close_window), (
    "A destroyed window must be filtered before hiCloseWindow"
)
assert "status=ALREADY_CLOSED" in cleanup, (
    "A window destroyed by dbPurge must be reported as successful cleanup"
)
assert "SCRATCH_OBJECT_DELETE" in delete_scratch, (
    "Scratch deletion must report its own result instead of only aggregate failure"
)

assert "cleanupResult = CWDeviceProxyCleanup(state key)" in abort, (
    "Manual abort must retain the real cleanup result"
)
assert "\n        cleanupResult\n    )\n)" in abort, (
    "Manual abort must return the real cleanup result"
)
