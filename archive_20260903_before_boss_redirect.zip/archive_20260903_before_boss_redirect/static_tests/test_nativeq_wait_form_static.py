from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_nativeq_wait_form_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

watch_start = source.index("procedure(CWDeviceWatchNative")
watch_end = source.index("procedure(CWDeviceFinishNative", watch_start)
watch = source[watch_start:watch_end]

assert "FORM_ACTION_PENDING" not in watch, "Native Q must not wait for or replace official form actions"
assert "hiChangeFormCallback(" not in watch, "Watcher must leave official PDK actions unchanged"
assert "state['formSeen] = t" in watch, "Watcher must record a visible Native Q"
assert "if(state['formSeen] then" in watch, "Watcher must not treat delayed display as closure"
assert "CWDeviceFinishNative(proxyKey)" in watch, "Watcher must finish only after a displayed form closes"
