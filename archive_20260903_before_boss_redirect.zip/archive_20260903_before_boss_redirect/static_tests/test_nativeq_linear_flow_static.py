from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_nativeq_linear_flow_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

assert "procedure(CWDeviceProxyStep" not in source, "Native Q must not use a phase state machine"
assert "state['phase]" not in source, "Native Q state must not contain phase transitions"

open_start = source.index("procedure(CWDeviceOpenNative")
open_end = source.index("procedure(CWDeviceWatchNative", open_start)
open_native = source[open_start:open_end]

watch_start = open_end
watch_end = source.index("procedure(CWDeviceFinishNative", watch_start)
watch_native = source[watch_start:watch_end]

finish_start = watch_end
finish_end = source.index("procedure(CWDeviceProxyAbort", finish_start)
finish_native = source[finish_start:finish_end]

assert open_native.index("deOpenCellView(") < open_native.index("dbCreateInst("), "Scratch must open before the official instance is created"
assert open_native.index("dbCreateInst(") < open_native.index("geSelectFig(targetInst)"), "Official instance must exist before selection"
assert "CWDeviceApplyNativeValues(sourceCdf values)" in open_native, "Saved native values must be applied before Native Q opens"
assert open_native.index("geSelectFig(targetInst)") < open_native.index("schHiObjectProperty()"), "Official instance must be selected before Native Q opens"
assert "CWDeviceWatchNative(%L)" in open_native, "Opening Native Q must schedule the passive watcher"

assert "state['formSeen] = t" in watch_native, "Watcher must remember that Native Q was displayed"
assert "if(state['formSeen] then" in watch_native, "Watcher must distinguish delayed display from a closed form"
assert "CWDeviceFinishNative(proxyKey)" in watch_native, "Only a previously displayed form may finish the proxy"
assert watch_native.index("if(state['formSeen] then") < watch_native.index("CWDeviceFinishNative(proxyKey)"), "Finish must be guarded by formSeen"
assert watch_native.count("hiRegTimer(") >= 2, "Watcher must continue both while waiting for display and while displayed"

assert "CWDeviceCaptureNativeValues(sourceCdf)" in finish_native, "Finish must read official committed CDF values"
assert "CWDeviceSetSnapshotValues(" in finish_native, "Finish must rebuild the wrapper snapshot"
assert "CWDeviceUpdateFromSnapshots(" in finish_native, "Finish must regenerate the wrapper from the snapshot"
assert "CWDeviceProxyCleanup(state proxyKey)" in finish_native, "Finish must clean the scratch context"
