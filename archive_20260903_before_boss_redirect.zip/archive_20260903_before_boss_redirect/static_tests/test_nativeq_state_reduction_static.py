from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_nativeq_state_reduction_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

assert "procedure(CWDeviceProxyStep" not in source, "Obsolete Native Q phase procedure must be removed"
assert "state['phase]" not in source, "Native Q must not store phase transitions"
assert "procedure(CWDeviceProxyActionWatchdog" not in source, "Obsolete Native Q watchdog must be removed"
assert "actionEpoch" not in source, "Obsolete watchdog generation state must be removed"
assert "procedure(CWDeviceOpenNative" in source, "Linear Native Q open entry point is required"
assert "procedure(CWDeviceWatchNative" in source, "One passive Native Q watcher is required"
assert "procedure(CWDeviceFinishNative" in source, "Linear Native Q finish entry point is required"
