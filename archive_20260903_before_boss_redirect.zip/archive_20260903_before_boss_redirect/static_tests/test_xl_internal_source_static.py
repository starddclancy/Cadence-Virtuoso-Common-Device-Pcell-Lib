from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_xl_internal_source_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

assert 'CWDeviceBuildId = "20260903-xl-internal-source-18"' in source
assert "procedure(CWDeviceEnableXLInternalSource()" in source

start = source.index("procedure(CWDeviceEnableXLInternalSource()")
body = source[start:]

required = (
    "layoutCv = geGetEditCellView()",
    "sourceCv = lxGetSource(layoutCv)",
    "selected = geGetSelSet()",
    "bndGetBoundObjects(layoutInst layoutCv)",
    "wrapperCv = dbGetAnyInstSwitchMaster(wrapperInst \"schematic\")",
    "innerInst = dbFindAnyInstByName(wrapperCv \"M0\")",
    "cphSetSchInstForceDescend(",
    "cphGetSchInstForceDescend(",
    "cphSetSchInstPhysicalBinding(",
    "bndSetInstsBindingByName(",
    'sourcePath = strcat(wrapperInst~>name "/M0")',
    "CWDeviceXL COMPLETE",
)
for token in required:
    assert token in body, f"missing XL internal-source behavior: {token}"

assert "lxUpdateBinding(" not in body, "The focused test must not rebind the whole design"
assert 'dbOpenCellViewByType(\n            layout' not in body
assert 'dbOpenCellViewByType(\n            "layout"' not in body

