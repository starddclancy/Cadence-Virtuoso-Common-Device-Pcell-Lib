from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_instance_name_property_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

assert "~>instName" not in source, "Database instance names must use the name property"
assert "candidate~>name" in source, "Form context must capture the candidate instance name"
assert "wrapperInst~>name" in source, "Proxy state must capture the wrapper instance name"
