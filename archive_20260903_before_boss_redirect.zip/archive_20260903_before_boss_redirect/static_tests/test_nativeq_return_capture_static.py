from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_nativeq_return_capture_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

open_start = source.index("procedure(CWDeviceOpenNative")
open_end = source.index("procedure(CWDeviceWatchNative", open_start)
open_native = source[open_start:open_end]

watch_start = open_end
watch_end = source.index("procedure(CWDeviceFinishNative", watch_start)
watch_native = source[watch_start:watch_end]

request_index = open_native.index("schHiObjectProperty()")
capture_index = open_native.index(
    "form = when(boundp('schObjPropForm) schObjPropForm)",
    request_index,
)

assert request_index < capture_index, "Native Q form must be captured after it is requested"
assert "state['form] = form" in open_native[capture_index:], "Returned Native Q form must be retained"
assert "state['formSeen] = t" in open_native[capture_index:], "A valid returned form proves Native Q appeared"

assert "form = state['form]" in watch_native, "Watcher must prefer the retained Native Q form"
assert watch_native.index("form = state['form]") < watch_native.index("boundp('schObjPropForm)"), (
    "Watcher must consult the global property form only when no retained form exists"
)
