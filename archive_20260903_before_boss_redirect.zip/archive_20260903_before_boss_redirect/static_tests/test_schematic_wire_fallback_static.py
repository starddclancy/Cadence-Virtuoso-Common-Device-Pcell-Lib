from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_schematic_wire_fallback_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

runtime_start = source.index("procedure(CWDeviceCreatePort")
runtime_end = source.index("procedure(CWDevicePCellBody", runtime_start)
runtime_port = source[runtime_start:runtime_end]

body_start = source.index("procedure(CWDeviceBuildPCellBody")
body_end = source.index("procedure(CWDeviceDefinePCell", body_start)
pcell_body = source[body_start:body_end]

for block in (runtime_port, pcell_body):
    assert "isCallable('schCreateWire)" in block, "Schematic wire API must be used when its context is loaded"
    assert "schCreateWire(" in block, "Schematic wire creation must be attempted first"
    assert "dbCreateLine(" in block, "Self-contained OA fallback must remain available for SI"
    assert block.index("schCreateWire(") < block.index("dbCreateLine("), "OA line must be the fallback path"
    assert "car(car(wireResult))" in block, "errset-wrapped schematic wire results must be unwrapped to one wire object"
    assert "dbAddFigToNet(wire net)" in block, "Every created segment must be assigned to the wrapper net"
