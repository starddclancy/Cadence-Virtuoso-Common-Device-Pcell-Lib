from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_form_context_placement_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

bind_start = source.index("procedure(CWDeviceBindFormContext")
bind_end = source.index("procedure(CWDeviceInvokeFormAction", bind_start) if "procedure(CWDeviceInvokeFormAction" in source else source.index("procedure(CWDeviceProxyCleanup", bind_start)
bind = source[bind_start:bind_end]

callback_start = source.index("procedure(CWDeviceWrapperCallback")
callback_end = source.index("procedure(CWDevice", callback_start + len("procedure(CWDeviceWrapperCallback"))
callback = source[callback_start:callback_end]

assert "get(cdfData 'id)" in bind, "Existing wrapper Q must prefer the effective CDF instance ID"
assert "FORM_CONTEXT_DEFERRED" in bind, "Create-instance form must be reported as deferred, not an error"
assert "FORM_CONTEXT_BIND" in bind, "A real existing-instance mismatch must remain diagnosable"
assert "'deferred" in bind, "Placement deferral result must be explicit"
assert "return(wrapperInst == 'deferred || wrapperInst != nil)" in callback, "Placement formInit must succeed without a persisted instance"
