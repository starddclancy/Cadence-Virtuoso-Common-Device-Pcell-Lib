from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_nativeq_empty_scratch_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

start = source.index("procedure(CWDeviceStartProxy")
end = source.index("procedure(CWDeviceWrapperCallback", start)
start_proxy = source[start:end]

open_start = source.index("procedure(CWDeviceOpenNative")
open_end = source.index("procedure(CWDeviceWatchNative", open_start)
open_native = source[open_start:open_end]

assert "dbCreateInst(" not in start_proxy, "Scratch must remain empty until the delayed open callback"
assert "cdfGetInstCDF(" not in start_proxy, "Native CDF initialization must follow delayed instance creation"
assert "deOpenCellView(" in open_native, "Delayed open must create the scratch graphical context"
assert open_native.index("deOpenCellView(") < open_native.index("dbCreateInst("), "Official target must be created after scratch open"
assert "CWDeviceProxyClosingForm" in start_proxy, "Wrapper form close must be guarded against callback re-entry"
