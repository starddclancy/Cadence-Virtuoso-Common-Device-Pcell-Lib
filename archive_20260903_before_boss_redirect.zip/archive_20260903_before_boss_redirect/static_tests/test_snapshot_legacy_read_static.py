from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_snapshot_legacy_read_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

read_start = source.index("procedure(CWDeviceSnapshotValues")
read_end = source.index("procedure(CWDeviceSetSnapshotValues", read_start)
read_snapshot = source[read_start:read_end]

validate_start = source.index("procedure(CWDeviceValidateSnapshots")
validate_end = source.index("procedure(CWDeviceUpdateFromSnapshots", validate_start)
validate_snapshot = source[validate_start:validate_end]

body_start = source.index("procedure(CWDeviceBuildPCellBody")
body_end = source.index("procedure(CWDeviceDefinePCell", body_start)
pcell_body = source[body_start:body_end]

assert "get(snapshot 'devices)" in read_snapshot, "Session reader must preserve Build 12 nested snapshots"
assert "get(legacyDevice 'parameters)" in read_snapshot, "Session reader must recover legacy native values"
assert "get(snapshot 'devices)" in validate_snapshot, "Validator must accept legacy snapshots during migration"

assert "get(tech 'devices)" in pcell_body, "Self-contained PCell must preserve legacy values before migration"
assert "get(legacyDevice 'parameters)" in pcell_body, "Self-contained PCell must read legacy parameter DPLs"
assert "dplp(" not in pcell_body, "Legacy compatibility must remain self-contained for SI"
