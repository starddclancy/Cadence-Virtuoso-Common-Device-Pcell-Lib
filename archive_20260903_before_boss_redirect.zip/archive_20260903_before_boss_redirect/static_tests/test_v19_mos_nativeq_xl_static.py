from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_v19_mos_nativeq_xl_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

assert 'CWDeviceBuildId = "20260903-xl-internal-source-19"' in source

geometry_start = source.index("procedure(CWDevicePortGeometry")
geometry_end = source.index("procedure(CWDeviceCreatePort", geometry_start)
geometry = source[geometry_start:geometry_end]

assert "portMap" in geometry
assert 'portName == "G"' in geometry
assert 'portName == "B"' in geometry
assert 'portName == "D" || portName == "S"' in geometry
assert 'oppositePortName = if(portName == "D" then "S" else "D")' in geometry
assert "cadr(pinPoint) == cadr(oppositePoint)" in geometry
assert "SOURCE_MOS_VERTICAL_DIRECTION" in geometry

body_start = source.index("procedure(CWDeviceBuildPCellBody")
body_end = source.index("procedure(CWDeviceDefinePCell", body_start)
pcell_body = source[body_start:body_end]

for token in (
    'isMos = assoc("D" nth(3 selectedData))',
    '&& assoc("G" nth(3 selectedData))',
    '&& assoc("S" nth(3 selectedData))',
    '&& assoc("B" nth(3 selectedData))',
    'isMos && portName == "G"',
    'isMos && portName == "B"',
    'isMos && (portName == "D" || portName == "S")',
    'oppositePortName = if(portName == "D" then "S" else "D")',
    "cadr(pinPoint) == cadr(oppositePoint)",
):
    assert token in pcell_body, f"missing self-contained MOS behavior: {token}"

native_start = source.index("procedure(CWDeviceConnectNativePorts")
native_end = source.index("procedure(CWDevicePCellBody", native_start)
native = source[native_start:native_end]

for token in (
    "wrapperInst~>instTerms",
    "wrapperInstTerm~>net~>name",
    "dbFindNetByName(scratch netName)",
    "dbCreateNet(scratch netName)",
    "geometry = CWDevicePortGeometry(",
    "portMap\n            )",
    "schCreateWire(",
    "dbAddFigToNet(wire net)",
    "dbCreateInstTerm(net targetInst sourceTerm)",
):
    assert token in native, f"missing Native-Q connectivity behavior: {token}"

open_start = source.index("procedure(CWDeviceOpenNative")
open_end = source.index("procedure(CWDeviceWatchNative", open_start)
open_native = source[open_start:open_end]
assert "CWDeviceConnectNativePorts(" in open_native
assert open_native.index("CWDeviceConnectNativePorts(") < open_native.index("cdfUpdateInstParam(targetInst)")

xl_start = source.index("procedure(CWDeviceEnableXLInternalSource()")
xl_end = source.index("procedure(CWDeviceEnsureRuntime", xl_start)
xl = source[xl_start:xl_end]

for token in (
    "lxUpdateBinding(",
    "?currentLevel nil",
    "?preserveExistingBindings t",
    "bndSetInstsBindingByName(",
    "lxHiUpdateLayoutParameters()",
):
    assert token in xl, f"missing XL hierarchy rebuild behavior: {token}"

assert xl.index("lxUpdateBinding(") < xl.index("bndSetInstsBindingByName(")
assert xl.index("bndSetInstsBindingByName(") < xl.index("lxHiUpdateLayoutParameters()")
assert "lxUpdateComponentsAndNets(" not in xl
