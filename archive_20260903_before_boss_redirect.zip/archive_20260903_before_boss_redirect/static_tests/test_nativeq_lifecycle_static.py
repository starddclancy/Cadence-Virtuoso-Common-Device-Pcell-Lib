from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_nativeq_lifecycle_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

open_start = source.index("procedure(CWDeviceOpenNative")
open_end = source.index("procedure(CWDeviceWatchNative", open_start)
open_native = source[open_start:open_end]

watch_start = open_end
watch_end = source.index("procedure(CWDeviceFinishNative", watch_start)
watch_native = source[watch_start:watch_end]

finish_start = watch_end
finish_end = source.index("procedure(CWDeviceProxyAbort", finish_start)
finish_native = source[finish_start:finish_end]

cleanup_start = source.index("procedure(CWDeviceProxyCleanup")
cleanup_end = source.index("procedure(CWDeviceDeleteScratch", cleanup_start)
cleanup = source[cleanup_start:cleanup_end]

assert "hiChangeFormCallback(" not in source, "Native Q must retain official PDK form actions"
assert "hiIsFormDisplayed(form)" in cleanup, "Cleanup must guard a displayed Native Q"
assert "return(t)" in cleanup, "Displayed Native Q cleanup must defer"
assert "hiRegTimer(resultString 2)" in cleanup, "Deferred cleanup must use the passive watcher"
assert "state['formSeen] = t" in watch_native, "Watcher must record the first visible form"
assert "if(state['formSeen] then" in watch_native, "Close detection must require a previously visible form"
assert "hiIsFormDisplayed(form)" in watch_native, "Watcher must observe official form visibility"
assert "CWDeviceCaptureNativeValues(sourceCdf)" in finish_native, "Finish must read committed official CDF values"
assert "CWDeviceProxyCleanup(state proxyKey)" in finish_native, "Finish must clean the temporary context"
