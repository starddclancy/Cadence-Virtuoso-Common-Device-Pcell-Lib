from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_v20_xl_all_bound_parameters_static.py CWDevicePCell.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

assert 'CWDeviceBuildId = "20260903-xl-all-bound-parameters-20"' in source

geometry_start = source.index("procedure(CWDevicePortGeometry")
geometry_end = source.index("procedure(CWDeviceCreatePort", geometry_start)
geometry = source[geometry_start:geometry_end]

for token in (
    "portMap",
    'portName == "G"',
    'portName == "B"',
    'portName == "D" || portName == "S"',
    'oppositePortName = if(portName == "D" then "S" else "D")',
    "cadr(pinPoint) == cadr(oppositePoint)",
    "SOURCE_MOS_VERTICAL_DIRECTION",
):
    assert token in geometry, f"missing MOS port behavior: {token}"

body_start = source.index("procedure(CWDeviceBuildPCellBody")
body_end = source.index("procedure(CWDeviceDefinePCell", body_start)
pcell_body = source[body_start:body_end]

for token in (
    'isMos = assoc("D" nth(3 selectedData))',
    '&& assoc("G" nth(3 selectedData))',
    '&& assoc("S" nth(3 selectedData))',
    '&& assoc("B" nth(3 selectedData))',
    'isMos && portName == "G"',
    'isMos && portName == "B"',
    'isMos && (portName == "D" || portName == "S")',
    'oppositePortName = if(portName == "D" then "S" else "D")',
    "cadr(pinPoint) == cadr(oppositePoint)",
):
    assert token in pcell_body, f"missing self-contained MOS behavior: {token}"

native_start = source.index("procedure(CWDeviceConnectNativePorts")
native_end = source.index("procedure(CWDevicePCellBody", native_start)
native = source[native_start:native_end]

for token in (
    "wrapperInst~>instTerms",
    "wrapperInstTerm~>net~>name",
    "dbFindNetByName(scratch netName)",
    "dbCreateNet(scratch netName)",
    "geometry = CWDevicePortGeometry(",
    "portMap\n            )",
    "schCreateWire(",
    "dbAddFigToNet(wire net)",
    "dbCreateInstTerm(net targetInst sourceTerm)",
):
    assert token in native, f"missing Native-Q connectivity behavior: {token}"

open_start = source.index("procedure(CWDeviceOpenNative")
open_end = source.index("procedure(CWDeviceWatchNative", open_start)
open_native = source[open_start:open_end]
assert "CWDeviceConnectNativePorts(" in open_native
assert open_native.index("CWDeviceConnectNativePorts(") < open_native.index("cdfUpdateInstParam(targetInst)")

xl_start = source.index("procedure(CWDeviceEnableXLInternalSource()")
xl_end = source.index("procedure(CWDeviceEnsureRuntime", xl_start)
xl = source[xl_start:xl_end]

for token in (
    "lxUpdateBinding(",
    "bndSetInstsBindingByName(",
    "lxUpdateComponentsAndNetsStart(",
    "lxSetGenerateOptions(",
    "?instances nil",
    "?stacks nil",
    "?folds nil",
    "?chainFolds nil",
    "?pins nil",
    "?globalPins nil",
    "?padPins nil",
    "?boundary nil",
    "?snapBoundary nil",
    "?mtm nil",
    "?extract nil",
    "lxSetUpdateOptions(",
    "?deletePins nil",
    "?deleteInstances nil",
    "?replaceMaster nil",
    "?netsOnly nil",
    "?selected t",
    "?layoutParameters t",
    "?layoutConstraints nil",
    "?sigType nil",
    "?netVoltage nil",
    "lxUpdateComponentsAndNetsFinish(",
    "cphGetLayoutXLConfig(layoutCv)",
    "cphGetParamNameMapping(physConfig sourcePath)",
    "cphGetParamToCheck(physConfig sourcePath)",
    "cphGetParamIgnoreForGen(",
    "physConfig\n                sourcePath",
    "geDeselectAllFig(layoutCv)",
    "geSelectFig(layoutInst)",
    "length(updateSelection) == 1",
    "&& car(updateSelection) == layoutInst",
    "CWDeviceXL PARAMETER_BINDING path=%s mapping=%L checked=%L ignoredForGeneration=%L",
    "CWDeviceXL UPDATE_PARAMETERS COMPLETE source=%s layout=%s scope=selected",
):
    assert token in xl, f"missing all-bound-parameter XL behavior: {token}"

assert xl.index("bndSetInstsBindingByName(") < xl.index("lxUpdateComponentsAndNetsStart(")
assert xl.index("lxUpdateComponentsAndNetsStart(") < xl.index("lxSetGenerateOptions(")
assert xl.index("lxSetGenerateOptions(") < xl.index("lxSetUpdateOptions(")
assert xl.index("lxSetUpdateOptions(") < xl.index("lxUpdateComponentsAndNetsFinish(")

for forbidden in (
    "lxHiUpdateLayoutParameters()",
    "cdfFindParamByName(",
    "dbReplaceProp(",
    "dbCreateInst(",
    "dbCreateParamInst(",
    'list("l" "nfin" "n" "m")',
):
    assert forbidden not in xl, f"XL path must not use manual parameter copying: {forbidden}"
