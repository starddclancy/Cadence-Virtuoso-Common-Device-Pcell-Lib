from pathlib import Path
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: test_libinit_session_only_static.py libInit.il")

source = Path(sys.argv[1]).read_text(encoding="ascii")

assert "prog((" in source, "libInit must provide a valid prog scope for early returns"
assert "CWDeviceSessionInitialize(wrapperLib yamlFile)" in source, "libInit must restore session runtime"
assert "CWDeviceInstall(" not in source, "libInit must not reinstall persistent PCell and CDF definitions"
assert "CWDeviceInitialize(" not in source, "libInit must not run the full initializer"
assert "CWDeviceDefinePCell(" not in source, "libInit must not redefine PCells"
assert "CWDeviceCreateCDF(" not in source, "libInit must not rebuild CDF"
assert "logFile" not in source, "Read-only deployed library initialization must not create a log file"
