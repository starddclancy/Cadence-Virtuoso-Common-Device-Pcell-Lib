# Device Wrapper PCell Phase Archive

Archive date: 2026-09-03

Archive reason: Freeze the current technical route before starting the new
direction provided after the management review. This archive is read-only
reference material. Future work must start from a new directory and build ID.

## Scope

This project is a schematic-only generic device wrapper PCell. It owns the
wrapper symbol/CDF, schematic PCell, Native-Q proxy, snapshots, netlisting
behavior, and Layout XL binding to official PDK layout PCells.

It does not define, copy, generate, or maintain a wrapper layout PCell. Layout
and maskLayout geometry remain owned by the official PDK.

## Frozen baselines

### Build 19: production-tested baseline

Package:

```text
packages/device_wrapper_production_20260903_xl_internal_source_19.zip
```

Build ID:

```text
20260903-xl-internal-source-19
```

SHA256:

```text
4c724e6009aaf4d533ca309aa398644059390e1c0b2cb1d8b3f463bcbc056a36
```

Confirmed in the company environment:

- The wrapper schematic PCell can contain the selected official PDK device.
- Native-Q can expose the official PDK CDF and callback behavior.
- CDL netlisting succeeds.
- SVS comparison between the wrapper-based CDL and the equivalent circuit
  without the wrapper PCell passes.
- Layout XL can call an official PDK layout device and establish a device
  relationship.

Known Build 19 problems:

- The generated/bound layout PCell is not a parameter-exact counterpart of the
  internal official schematic `M0`. Earlier observation showed only `m`
  reaching layout correctly; the complete official bound parameter set does
  not synchronize.
- Post-generation `lxHiUpdateLayoutParameters()` does not correct that source
  counterpart problem.
- Native-Q scratch connectivity displays local net names such as `net1` through
  `net4`; these do not provide the expected external pin/net correspondence.
  The existing code reads `wrapperInstTerm~>net~>name`, so the next diagnostic
  must distinguish an automatically named parent net from an incorrectly
  resolved wrapper occurrence.
- HSPICE-D and Spectre netlisting fail with a generic wrapper schematic PCell
  evaluation marker. The exact `drcWhy`/`errorDesc` text has not yet been
  captured, so the failing PCell operation is not established.

### Build 20: local experimental branch, do not deploy

Package:

```text
packages/device_wrapper_production_20260903_xl_all_bound_parameters_20.zip
```

Build ID:

```text
20260903-xl-all-bound-parameters-20
```

SHA256:

```text
a9757d7888a7723a889df6e0db86361d86fba27315925ecbc75d3c84ac9644a1
```

Build 20 replaces the interactive parameter-update launcher with a selected,
parameter-only Update Components and Nets flow. It contains no
`l/nfin/n/m` whitelist, YAML XL parameter list, or manual same-name property
copy.

Build 20 was not tested in Virtuoso. Later review found that it still performs
a cellview-wide `lxUpdateBinding()` before the selected update and can leave
partially changed XL state on failure. It therefore does not establish the
required solution and must not be used as a production candidate.

## Last technical conclusion before route change

The remaining XL problem is earlier than parameter copying. The official PDK
schematic instance `wrapper/M0` must be recognized as the Layout XL source leaf
before layout generation. Updating parameters after layout generation cannot
repair an incorrect schematic counterpart.

The unimplemented candidate direction was:

1. Obtain the active Layout XL physical configuration.
2. Set the wrapper cell to force-descend before the user generates layout
   devices.
3. Rebuild the source hierarchy so `wrapper/M0` is the official source leaf.
4. Let the official PDK physical binding generate the official layout PCell and
   transfer every parameter covered by the PDK's own parameter rules.

The exact ICADV12.3 offline API references found for this investigation include
`cphGetLayoutXLConfig()`, `cphSetCellForceDescend()`,
`cphGetCellForceDescend()`, `cphSetSchInstPhysicalBinding()`,
`bndSetInstsBindingByName()`, and `lxUpdateBinding()`. Their IC25.1 behavior was
not validated.

## Netlisting diagnostic still required

For the HSPICE-D/Spectre failure, select the PCell `marker/error` shape and
capture the exact marker properties before changing source:

```skill
marker = car(geGetSelSet())
printf(
    "drcWhy=%L errorDesc=%L\n"
    marker~>drcWhy
    marker~>errorDesc
)
```

CDL success does not prove HSPICE-D or Spectre PCell evaluation compatibility.

## Archive contents

- `packages/`: immutable Build 19 and Build 20 zip packages.
- `sources/`: expanded source directories matching the packages.
- `static_tests/`: local static regression scripts available at the freeze
  point.
- `SHA256SUMS.txt`: hashes of every archived file except itself.

## Validation boundary

Static checks cover source formatting, parentheses, known code-shape
regressions, package contents, and file integrity. They do not prove live
Virtuoso, OA, PDK callback, Layout XL, HSPICE-D, Spectre, or SI behavior.

Company-environment results above are based on the user's reported tests. Build
20 has no company-environment validation.

